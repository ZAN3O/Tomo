//
//  CardView.swift
//  Tomo
//
//  Created by Simon Steuer on 06/08/2025.
//

import SwiftUI

struct CardView: View {
    let item: MenuItem
    @ObservedObject var viewModel: MenuViewModel
    @State private var addedToCart = false

    // 📏 Dimensions fixes
    private let cardWidth: CGFloat  = 128
    private let cardHeight: CGFloat = 175
    private let imageHeight: CGFloat = 112
    private let cornerRadius: CGFloat = 16

    var body: some View {
        // Carte entière, taillée et masquée une seule fois
        ZStack(alignment: .top) {
            VStack(spacing: 0) {
                Image(item.id)
                    .resizable()
                    .scaledToFill()
                    .frame(width: cardWidth, height: imageHeight)
                    .clipped()
                Spacer(minLength: 0)
            }

            VStack(spacing: 0) {
                Spacer().frame(height: imageHeight) // décale le contenu sous l'image

                VStack(alignment: .leading, spacing: 4) {
                    Text(item.id)
                        .font(.custom("Barlow-SemiBold", size: 16))
                        .foregroundColor(.black)
                        .lineLimit(1)

                    Text(String(format: "%.2f €", item.price))
                        .font(.custom("Barlow", size: 13))
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.white)
            }

            // 3) Bouton +
            VStack {
                HStack {
                    Spacer()
                    Button {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { addedToCart = true }
                        viewModel.addToCart(by: item.id)
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                            withAnimation(.easeInOut(duration: 0.25)) { addedToCart = false }
                        }
                    } label: {
                        Image(systemName: addedToCart ? "checkmark" : "plus")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 35, height: 35)
                            .background(addedToCart ? Color.pink : Color.black)
                            .clipShape(Circle())
                    }
                    .padding(6)
                }
                Spacer()
            }
        }
        .frame(width: cardWidth, height: cardHeight)
        .background(Color.white)
        .mask(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)) // ✅ même arrondi partout
        .overlay(
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .stroke(Color.black.opacity(0.06), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.04), radius: 3, x: 0, y: 2)
        .onDrag { NSItemProvider(object: item.id as NSString) }
    }
}
