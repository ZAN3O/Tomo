import SwiftUI
import FirebaseAuth

struct MainView: View {
    @StateObject private var viewModel = MenuViewModel()
    @State private var isShowingBasket = false
    @State private var showAccountSheet = false
    @State private var signOutError: String?

    @State private var searchText: String = ""
    @State private var selectedFromSearch: MenuItem?

    private var userInitials: String {
        if let user = Auth.auth().currentUser {
            if let name = user.displayName, !name.trimmingCharacters(in: .whitespaces).isEmpty {
                return Self.initials(from: name)
            }
            if let email = user.email, !email.isEmpty {
                let base = email.split(separator: "@").first.map(String.init) ?? ""
                return Self.initials(from: base)
            }
        }
        return "TU"
    }

    private var searchResults: [MenuItem] {
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return [] }
        return viewModel.items.filter { item in
            item.id.lowercased().contains(q) ||
            item.name.lowercased().contains(q) ||
            item.description.lowercased().contains(q)
        }
    }

    var body: some View {
        NavigationStack {
            let totalItems = viewModel.cart.reduce(0) { $0 + $1.quantity }

            ZStack {
                // --- Contenu principal ---
                VStack(spacing: 16) {
                    // Header
                    HStack {
                        Text("Bienvenue")
                            .font(.custom("Barlow-Bold", size: 45))
                            .bold()
                        Spacer()
                        Button { showAccountSheet = true } label: {
                            AvatarInitials(initials: userInitials, size: 46, corner: 12)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                    // Barre de recherche
                    SearchBar(text: $searchText)
                        .padding(.horizontal, 16)

                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(alignment: .leading, spacing: 16) {
                            ForEach(MenuCategory.allCases, id: \.self) { category in
                                let filtered = viewModel.items.filter { $0.tag.contains(category.tag) }
                                if !filtered.isEmpty {
                                    SectionView(
                                        title: category.rawValue,
                                        items: filtered,
                                        onDropInBasket: viewModel.addToCart(by:),
                                        viewModel: viewModel
                                    )
                                }
                            }
                        }
                        //.padding(.horizontal, 12)
                        .padding(.bottom, 8)
                    }
                }
                .background(Color(.systemGray6))
                .ignoresSafeArea(edges: .bottom)

                // --- Résultats de recherche plein écran ---
                if !searchResults.isEmpty {
                    Color(.systemGray6)
                        .ignoresSafeArea()
                    VStack(spacing: 10) {
                        // Barre de recherche fixe en haut
                        HStack {
                            SearchBar(text: $searchText)
                                .padding(.horizontal, 16)
                        }
                        .padding(.top, 8)

                        // Liste des résultats
                        SearchResultsList(
                            items: searchResults,
                            onSelect: { item in
                                selectedFromSearch = item
                                searchText = ""
                            }
                        )
                        .padding(.horizontal, 16)
                        .padding(.top, 8)
                        Spacer()
                    }
                    .zIndex(2)
                    .transition(.opacity)
                }
            }
            // Navigation vers fiche depuis recherche
            .navigationDestination(item: $selectedFromSearch) { item in
                MenuItemDetailView(item: item, viewModel: viewModel)
            }
        }
        // Bouton panier flottant
        .overlay(alignment: .bottomTrailing) {
            BasketButton(itemCount: viewModel.cart.reduce(0) { $0 + $1.quantity })
                .onTapGesture { isShowingBasket = true }
                .padding(.trailing, 20)
                .padding(.bottom, 30)
                .zIndex(1000)
        }
        .fullScreenCover(isPresented: $isShowingBasket) {
            BasketView(viewModel: viewModel, isPresented: $isShowingBasket)
        }
        .sheet(isPresented: $showAccountSheet) {
            AccountSheetLarge(signOutError: $signOutError)
                .presentationDetents([.fraction(0.92)])
                //.presentationDragIndicator(.visible)
                .presentationCornerRadius(28)
        }
    }

    private static func initials(from name: String) -> String {
        let parts = name.trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: .whitespaces)
            .filter { !$0.isEmpty }
        if parts.count >= 2 {
            return (String(parts[0].first!) + String(parts[1].first!)).uppercased()
        } else if let first = parts.first?.first {
            return String(first).uppercased()
        } else {
            return "TU"
        }
    }
}

struct SearchBar: View {
    @Binding var text: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.gray)

            TextField("", text: $text)
                .font(.custom("barlow", size: 16))
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
                .placeholder(when: text.isEmpty, alignment: .leading) {
                    Text("Rechercher un plat…")
                        .font(.custom("barlow", size: 16))
                        .foregroundColor(.secondary)
                }
        }
        .padding(.horizontal, 12)
        .frame(height: 44)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

struct SearchResultsList: View {
    let items: [MenuItem]
    let onSelect: (MenuItem) -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                ForEach(items) { item in
                    Button {
                        onSelect(item)
                    } label: {
                        HStack(spacing: 12) {
                            Image(item.id)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 10))

                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.id)
                                    .font(.custom("Barlow-Bold", size: 16))
                                    .foregroundColor(.black)
                                Text(String(format: "%.2f €", item.price))
                                    .font(.custom("barlow", size: 14))
                                    .foregroundColor(.secondary)
                            }

                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.secondary)
                        }
                        .padding(12)
                        .background(Color.white)
                        .cornerRadius(12)
                        .shadow(color: .black.opacity(0.04), radius: 3, x: 0, y: 1)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 6)
        }
    }
}

extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder _ placeholder: () -> Content
    ) -> some View {
        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}
