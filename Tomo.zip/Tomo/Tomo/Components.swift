//
//  Components.swift
//  Tomo
//
//  Created by Simon Steuer on 09/08/2025.
//

import SwiftUI

struct LabeledField: View {
    let title: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.custom("Barlow-Bold", size: 14))
                .foregroundColor(.gray)
            TextField(title, text: $text)
                .keyboardType(keyboard)
                .padding(12)
                .background(Brand.field)
                .cornerRadius(10)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Brand.border))
        }
    }
}

struct SecureLabeledField: View {
    let title: String
    @Binding var text: String
    @State private var secure = true

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.custom("Barlow-Bold", size: 14))
                .foregroundColor(.gray)
            HStack {
                Group {
                    if secure { SecureField(title, text: $text) }
                    else { TextField(title, text: $text) }
                }
                Button(action: { secure.toggle() }) {
                    Image(systemName: secure ? "eye.slash" : "eye")
                        .foregroundStyle(.secondary)
                }
            }
            .padding(12)
            .background(Brand.field)
            .cornerRadius(10)
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Brand.border))
        }
    }
}
