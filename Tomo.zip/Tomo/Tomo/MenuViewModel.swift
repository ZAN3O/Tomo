//
//  MenuViewModel.swift
//  Tomo
//
//  Created by Simon Steuer on 05/08/2025.
//
import Foundation
import FirebaseAuth
import FirebaseFirestore

class MenuViewModel: ObservableObject {
    @Published var items: [MenuItem] = []
    @Published var cart: [MenuItem] = []
        @Published var orders: [Order] = []

        private var ordersListener: ListenerRegistration?

    init() {
        loadMenu()
    }

    private func loadMenu() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let url = Bundle.main.url(forResource: "menu", withExtension: "json") else { return }

            do {
                let data = try Data(contentsOf: url)
                let decoded = try JSONDecoder().decode([String: [MenuItem]].self, from: data)
                let items = decoded["items"] ?? []

                DispatchQueue.main.async {
                    self?.items = items
                }
            } catch {
                print("Erreur de lecture JSON:", error)
            }
        }
    }
    func clearCart() {
        cart.removeAll()
    }

    func addToCart(by id: String) {
        if let index = cart.firstIndex(where: { $0.id == id }) {
            cart[index].quantity += 1
        } else if let item = items.first(where: { $0.id == id }) {
            var newItem = item
            newItem.quantity = 1
            cart.append(newItem)
        }
    }

    func increaseQuantity(of item: MenuItem) {
        if let index = cart.firstIndex(where: { $0.id == item.id }) {
            cart[index].quantity += 1
        }
    }

    func decreaseQuantity(of item: MenuItem) {
        if let index = cart.firstIndex(where: { $0.id == item.id }) {
            if cart[index].quantity > 1 {
                cart[index].quantity -= 1
            } else {
                cart.remove(at: index)
            }
        }
    }

    var total: Double {
        cart.reduce(0) { $0 + ($1.price * Double($1.quantity)) }
    }
    func fetchOrders(forAdmin: Bool = false) {
            ordersListener?.remove()

            let db = Firestore.firestore()
            var query: Query = db.collection("orders").order(by: "timestamp", descending: true)

            if !forAdmin {
                guard let uid = Auth.auth().currentUser?.uid else {
                    DispatchQueue.main.async { self.orders = [] }
                    return
                }
                query = query.whereField("userId", isEqualTo: uid)
            }

            ordersListener = query.addSnapshotListener { [weak self] snap, err in
                if let err = err {
                    print("fetchOrders error:", err.localizedDescription)
                    return
                }
                guard let docs = snap?.documents else {
                    DispatchQueue.main.async { self?.orders = [] }
                    return
                }

                let mapped: [Order] = docs.map { doc in
                    let data = doc.data()

                    let userId = data["userId"] as? String ?? ""
                    let customerName =
                        (data["customerName"] as? String) ??
                        (data["fullName"] as? String) ??    
                        "Client"

                    let address = data["address"] as? String ?? "—"

                    // total (Double/Int/NSNumber)
                    let totalAny = data["total"]
                    let total: Double = {
                        if let d = totalAny as? Double { return d }
                        if let i = totalAny as? Int { return Double(i) }
                        if let n = totalAny as? NSNumber { return n.doubleValue }
                        return 0
                    }()

                    // itemCount direct, sinon calcul via items[]
                    let itemCountDirect = data["itemCount"] as? Int
                    let itemsArray = data["items"] as? [[String: Any]]
                    let itemsParsed: [OrderItem] = (itemsArray ?? []).map { d in
                        let name  = d["name"] as? String ?? "—"
                        let q     = d["quantity"] as? Int ?? 0
                        let pAny  = d["price"]
                        let price: Double = {
                            if let v = pAny as? Double { return v }
                            if let v = pAny as? Int { return Double(v) }
                            if let v = pAny as? NSNumber { return v.doubleValue }
                            return 0
                        }()
                        return OrderItem(name: name, price: price, quantity: q)
                    }
                    let itemsCount = itemCountDirect ?? itemsParsed.reduce(0) { $0 + $1.quantity }

                    // timestamp prioritaire, fallback createdAt sinon
                    let createdAt: Date = (data["timestamp"] as? Timestamp)?.dateValue()
                        ?? (data["createdAt"] as? Timestamp)?.dateValue()
                        ?? Date()

                    let status = (data["status"] as? String) ?? "pending"

                    return Order(
                        id: doc.documentID,
                        userId: userId,
                        customerName: customerName,
                        address: address,
                        total: total,
                        itemsCount: itemsCount,
                        createdAt: createdAt,
                        status: status,
                        items: itemsParsed
                    )
                }

                DispatchQueue.main.async { self?.orders = mapped }
            }
    }
}
