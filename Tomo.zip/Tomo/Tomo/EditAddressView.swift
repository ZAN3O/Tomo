//
//  EditAddressView.swift
//  Tomo
//
//  Created by Simon Steuer on 09/08/2025.
//

import SwiftUI
import MapKit

struct EditAddressView: View {
    @Binding var address: String
    @State private var searchQuery = ""
    @State private var searchResults: [MKMapItem] = []
    @FocusState private var isSearchFocused
    
    var body: some View {
        VStack(spacing: 12) {
            
            // Champ de recherche stylé
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                
                TextField("Rechercher une adresse à Saint-Mandé", text: $searchQuery, onCommit: searchForAddress)
                    .focused($isSearchFocused)
                    .submitLabel(.search)
                
                if !searchQuery.isEmpty {
                    Button(action: { searchQuery = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 10)
            .background(Color(.systemGray6))
            .cornerRadius(12)
            .padding(.horizontal)
            .padding(.top, 12)
            
            // Liste filtrée
            List {
                ForEach(filteredResults, id: \.self) { item in
                    Button(action: {
                        address = item.placemark.title ?? ""
                        isSearchFocused = false
                    }) {
                        VStack(alignment: .leading) {
                            Text(item.name ?? "Adresse inconnue")
                                .font(.headline)
                            Text(item.placemark.title ?? "")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .listStyle(PlainListStyle())
        }
    }
    
    // Résultats filtrés
    private var filteredResults: [MKMapItem] {
        searchResults.filter {
            let title = ($0.placemark.title ?? "").lowercased()
            return title.contains("94160") || title.contains("saint-mandé")
        }
    }
    
    // Recherche d'adresses
    private func searchForAddress() {
        guard !searchQuery.isEmpty else {
            searchResults = []
            return
        }
        
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchQuery
        request.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 48.8456, longitude: 2.4155), // Centre de Saint-Mandé
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
        
        let search = MKLocalSearch(request: request)
        search.start { response, _ in
            if let items = response?.mapItems {
                searchResults = items
            }
        }
    }
}

extension MKCoordinateRegion: Equatable {
    public static func == (lhs: MKCoordinateRegion, rhs: MKCoordinateRegion) -> Bool {
        lhs.center.latitude == rhs.center.latitude &&
        lhs.center.longitude == rhs.center.longitude &&
        lhs.span.latitudeDelta == rhs.span.latitudeDelta &&
        lhs.span.longitudeDelta == rhs.span.longitudeDelta
    }
}
