//
//  AccountSheet.swift
//  Tomo
//

import SwiftUI
import FirebaseAuth
import MapKit

// Avatar carré arrondi avec initiales
struct AvatarInitials: View {
    let initials: String
    var size: CGFloat = 44
    var corner: CGFloat = 12

    var body: some View {
        RoundedRectangle(cornerRadius: corner, style: .continuous)
            .fill(Color(.systemGray5))
            .frame(width: size, height: size)
            .overlay(
                Text(initials)
                    .font(.custom("Barlow-Bold", size: max(18, size * 0.42)))
                    .foregroundStyle(.primary)
            )
            .overlay(
                RoundedRectangle(cornerRadius: corner)
                    .stroke(Color.black.opacity(0.06), lineWidth: 1)
            )
    }
}

// === Feuille Compte quasi plein écran ===

struct AccountSheetLarge: View {
    @Binding var signOutError: String?
    @AppStorage("userAddress") private var storedAddress: String = "12 rue Jean Mermoz, Saint-Mandé"

    @State private var isEditingAddress = false
    @State private var searchQuery = ""
    @State private var searchResults: [MKMapItem] = []
    @FocusState private var isSearchFocused

    var body: some View {
        VStack(spacing: 24) {
            // --- Avatar + infos utilisateur ---
            VStack(spacing: 8) {
                AvatarInitials(initials: initials, size: 90, corner: 20)
                Text(Auth.auth().currentUser?.displayName ?? "Tomo User")
                    .font(.custom("Barlow-Bold", size: 22))
                Text(Auth.auth().currentUser?.email ?? "")
                    .foregroundColor(.secondary)
            }

            // --- Adresse de livraison ---
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Adresse de livraison")
                        .font(.custom("Barlow-Bold", size: 18))
                    Spacer()
                    Button(action: {
                        withAnimation(.spring()) {
                            isEditingAddress.toggle()
                            if isEditingAddress {
                                isSearchFocused = true
                            }
                        }
                    }) {
                        Text(isEditingAddress ? "Annuler" : "Modifier")
                            .font(.custom("Barlow-Bold", size: 14))
                            .foregroundColor(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color.black)
                            .cornerRadius(8)
                    }
                }

                Text(storedAddress)
                    .foregroundColor(.secondary)
                    .font(.custom("Barlow-Regular", size: 16))

                if isEditingAddress {
                    VStack(spacing: 8) {
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.gray)

                            TextField("Rechercher une adresse à Saint-Mandé", text: $searchQuery)
                                .focused($isSearchFocused)
                                .onChange(of: searchQuery) { _ in
                                    searchForAddress()
                                }

                            if !searchQuery.isEmpty {
                                Button(action: { searchQuery = "" }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.gray)
                                }
                            }
                        }
                        .padding(.horizontal)
                        .padding(.vertical, 10)
                        .background(Color(.systemGray6))
                        .cornerRadius(12)

                        ForEach(filteredResults, id: \.self) { item in
                            Button {
                                storedAddress = item.placemark.title ?? ""
                                withAnimation(.spring()) {
                                    isEditingAddress = false
                                }
                            } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.name ?? "Adresse inconnue")
                                        .font(.custom("Barlow-Bold", size: 16))
                                        .foregroundColor(.black)
                                    Text(item.placemark.title ?? "")
                                        .font(.custom("Barlow", size: 14))
                                        .foregroundColor(.gray)
                                }
                                .padding(.vertical, 6)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.white)
            .cornerRadius(14)
            .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

            Spacer()

            // --- Boutons actions ---
            VStack(spacing: 14) {
                Button {
                } label: {
                    HStack {
                        Image(systemName: "person.circle.fill")
                        Text("Gérer mon profil")
                            .font(.custom("Barlow-Bold", size: 16))
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.black)
                    .cornerRadius(12)
                }

                Button {
                    do {
                        try Auth.auth().signOut()
                    } catch {
                        signOutError = error.localizedDescription
                    }
                } label: {
                    HStack {
                        Image(systemName: "arrow.right.square")
                        Text("Se déconnecter")
                            .font(.custom("Barlow-Bold", size: 16))
                        Spacer()
                    }
                    .foregroundColor(.red)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                }
            }
        }
        .padding()
    }

    // MARK: - Utils
    private var initials: String {
        let user = Auth.auth().currentUser
        let name = user?.displayName ?? user?.email ?? "TU"
        let comps = name.split(separator: " ")
        if comps.count >= 2 {
            return (String(comps[0].first!) + String(comps[1].first!)).uppercased()
        } else if let first = name.first {
            return String(first).uppercased()
        } else {
            return "TU"
        }
    }

    private var filteredResults: [MKMapItem] {
        searchResults.filter {
            let title = ($0.placemark.title ?? "").lowercased()
            return title.contains("94160") || title.contains("saint-mandé")
        }
    }

    private func searchForAddress() {
        guard !searchQuery.isEmpty else {
            searchResults = []
            return
        }
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchQuery
        request.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 48.8456, longitude: 2.4155),
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
        let search = MKLocalSearch(request: request)
        search.start { response, _ in
            if let items = response?.mapItems {
                searchResults = items
            }
        }
    }
}
