//
//  MenuItem.swift
//  Tomo
//
//  Created by Simon Steuer on 05/08/2025.
//

import Foundation

struct MenuItem: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let description: String
    let price: Double
    let tag: String
    var quantity: Int

    enum CodingKeys: CodingKey {
        case id, name, description, price, tag
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(String.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        description = try container.decode(String.self, forKey: .description)
        price = try container.decode(Double.self, forKey: .price)
        tag = try container.decode(String.self, forKey: .tag)
        quantity = 1
    }

    init(id: String, name: String, description: String, price: Double, tag: String, quantity: Int = 1) {
        self.id = id
        self.name = name
        self.description = description
        self.price = price
        self.tag = tag
        self.quantity = quantity
    }
}
