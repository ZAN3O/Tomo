import SwiftUI

struct MainTabView: View {
    @State private var selectedIndex: Int = 0

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                switch selectedIndex {
                case 0:
                    MainView()
//                case 1:
                    //ProfileView()
                default:
                    MainView()
                }
            }

            BottomNavBar(selectedIndex: $selectedIndex)
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
    }
}
