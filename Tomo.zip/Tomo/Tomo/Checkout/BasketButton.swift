//
//  BasketButton.swift
//  Tomo
//
//  Created by Simon Steuer on 06/08/2025.
//
import SwiftUI

struct BasketButton: View {
    //let onDropItem: (String) -> Void
    let itemCount: Int

    var body: some View {
        ZStack {
            Circle()
                .fill(Color.pink)
                .frame(width: 80, height: 80)
                .shadow(radius: 4)

            Image(systemName: "cart.fill")
                .foregroundColor(.white)
                .font(.title)
            if itemCount > 0 {
                            Text("\(itemCount)")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(Color.pink) // texte rose
                                .padding(6)
                                .background(Color.white) // fond blanc
                                .clipShape(Circle())
                                .overlay(
                                    Circle().stroke(Color.pink, lineWidth: 1) // petit contour rose
                                )
                                .offset(x: 12, y: -12) // placement au bord
                        }		
        }
        /*.onDrop(of: [.text], isTargeted: nil) { providers in
            if let provider = providers.first {
                _ = provider.loadObject(ofClass: NSString.self) { (object, error) in
                    if let id = object as? String {
                        DispatchQueue.main.async {
                            onDropItem(id)
                        }
                    }
                }
                return true
            }
            return false
        }*/
    }
}
