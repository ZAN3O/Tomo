import SwiftUI

struct BasketView: View {
    @ObservedObject var viewModel: MenuViewModel
    @Binding var isPresented: Bool // ← Ajouté
    @AppStorage("userAddress") private var storedAddress: String = "12 rue Jean Mermoz, Saint-Mandé"
    @State private var showCheckout = false
    
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack { // ✅ Ajout d'une pile interne
            VStack(spacing: 0) {
                
                // ✅ Bouton retour custom
                HStack {
                    Button(action: { dismiss() }) {
                        HStack(spacing: 6) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .bold))
                            Text("Retour")
                                .font(.custom("Barlow-Bold", size: 18))
                        }
                        .foregroundColor(.white)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 14)
                        .background(Color.pink)
                        .cornerRadius(20)
                    }
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 10)
                
                // ✅ Titre
                HStack {
                    Text("Mon panier")
                        .font(.custom("Barlow-Bold", size: 28))
                    Spacer()
                }
                .padding()

                // ✅ Liste des items
                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(viewModel.cart) { item in
                            HStack(alignment: .top, spacing: 16) {
                                Image(item.id)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 80, height: 90)
                                    .cornerRadius(10)
                                    .clipped()

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.id)
                                        .font(.custom("barlow", size: 16))
                                    Text(item.description ?? "Item description here...")
                                        .font(.custom("barlow", size: 14))
                                        .foregroundColor(.gray)
                                        .lineLimit(2)
                                    Text(String(format: "%.2f €", item.price))
                                        .font(.custom("Barlow-Bold", size: 16))
                                        .padding(.top, 4)
                                }

                                Spacer()

                                VStack {
                                    Spacer()
                                    HStack(spacing: 8) {
                                        Button(action: {
                                            viewModel.decreaseQuantity(of: item)
                                        }) {
                                            Image(systemName: "minus")
                                                .foregroundStyle(.black)
                                                .frame(width: 30, height: 30)
                                                .background(Color(.systemGray5))
                                                .clipShape(Circle())
                                        }

                                        Text("\(item.quantity)")
                                            .font(.system(size: 16, weight: .semibold))
                                            .frame(minWidth: 20)

                                        Button(action: {
                                            viewModel.increaseQuantity(of: item)
                                        }) {
                                            Image(systemName: "plus")
                                                .foregroundStyle(.black)
                                                .frame(width: 30, height: 30)
                                                .background(Color(.systemGray5))
                                                .clipShape(Circle())
                                        }
                                    }
                                    Spacer()
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.top, 8)
                }

                // ✅ Total + bouton checkout
                VStack(spacing: 12) {
                    HStack {
                        Text("Total")
                            .font(.custom("Barlow-Bold", size: 16))
                        Spacer()
                        Text(String(format: "%.2f €", viewModel.total))
                            .font(.system(size: 18, weight: .bold))
                    }

                    Button(action: {
                        showCheckout = true
                    }) {
                        Text("Finaliser la commande")
                            .foregroundColor(.white)
                            .font(.custom("Barlow-Bold", size: 18))
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(viewModel.cart.isEmpty ? Color.pink.opacity(0.4) : Color.pink)
                            .cornerRadius(12)
                    }
                    .disabled(viewModel.cart.isEmpty)
                }
                .padding()
                .background(Color.white)
                .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: -2)
            }
            .background(Color(.systemGroupedBackground))
            .navigationBarBackButtonHidden(true)
            // ✅ Navigation interne
            .background(
                NavigationLink(
                    destination: CheckoutInfoView(
                        vm: CheckoutViewModel(from: viewModel, address: storedAddress), menuModel: viewModel
                        ,
                        isPresented: $isPresented
                    ),
                    isActive: $showCheckout
                ) { EmptyView() }
                .hidden()

                )
        }
    }
}

#Preview {
    ContentView()
}
