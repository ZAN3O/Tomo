//
//  OrderTrackingView.swift
//  Tomo
//
//  Created by Simon Steuer on 08/08/2025.
//

import SwiftUI

struct OrderTrackingView: View {
    @Binding var isPresented: Bool

    var body: some View {
        VStack(spacing: 16) {
            Spacer()

            Image(systemName: "bicycle.circle.fill")
                .font(.system(size: 90))
                .foregroundColor(.pink)

            Text("Votre commande est en route")
                .font(.custom("Barlow-Bold", size: 28))
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            Text("Un livreur est en chemin. Vous recevrez une notification à l’arrivée.")
                .font(.custom("barlow", size: 15))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            Spacer()

            Button {
                isPresented = false 
            } label: {
                Text("Retour à l’accueil")
                    .foregroundColor(.white)
                    .font(.custom("Barlow-Bold", size: 18))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.pink)
                    .cornerRadius(12)
            }
            .padding(.horizontal)
            .padding(.bottom)
        }
        .background(Color(.systemGray6))
        .navigationBarBackButtonHidden(true)
    }
}




