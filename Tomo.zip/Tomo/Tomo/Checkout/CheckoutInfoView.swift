//
//  CheckoutInfoView.swift
//  Tomo
//
//  Created by Simon Steuer on 08/08/2025.
//


import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import MapKit

struct CheckoutInfoView: View {
    @ObservedObject var vm: CheckoutViewModel
    @ObservedObject var menuModel: MenuViewModel
    @Binding var isPresented: Bool
    @State private var isEditingAddress = false
    @State private var searchQuery = ""
    @State private var searchResults: [MKMapItem] = []
    @FocusState private var isSearchFocused
    @State private var isSaving = false
    @State private var showSaveAlert = false

    // 🔹 Nouveau : navigation interne vers OrderTrackingView
    @State private var goToTracking = false
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {

            // 🔹 Bouton retour comme dans BasketView
            HStack {
                Button(action: { dismiss() }) {
                    HStack(spacing: 6) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: .bold))
                        Text("Retour")
                            .font(.custom("Barlow-Bold", size: 18))
                    }
                    .foregroundColor(.white)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 14)
                    .background(Color.pink)
                    .cornerRadius(20)
                }
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 8)

            // 🔹 Contenu scrollable
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    recapSection
                    addressSection
                }
                .padding()
            }
        }
        .navigationBarBackButtonHidden(true)
        .safeAreaInset(edge: .bottom) {
            finalButton
                .background(Color.white)
                .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: -2)
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)

        // ✅ Navigation vers OrderTrackingView après enregistrement
        .background(
            NavigationLink(
                destination: OrderTrackingView(isPresented: $isPresented),
                isActive: $goToTracking
            ) { EmptyView() }
            .hidden()
        )
    }

    // MARK: - Sections
    private var recapSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Récapitulatif de commande")
                .font(.custom("Barlow-Bold", size: 20))
            Text("Total : \(String(format: "%.2f €", vm.total))")
                .font(.custom("Barlow-Bold", size: 18))
                .foregroundColor(.pink)
            Text("\(vm.itemCount) articles")
                .foregroundColor(.secondary)
                .font(.custom("Barlow-Regular", size: 16))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }

    private var addressSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Adresse de livraison")
                    .font(.custom("Barlow-Bold", size: 20))
                Spacer()
                Button(isEditingAddress ? "Annuler" : "Modifier") {
                    withAnimation(.spring()) {
                        isEditingAddress.toggle()
                        if isEditingAddress {
                            isSearchFocused = true
                        }
                    }
                }
                .font(.custom("Barlow", size: 16))
                .foregroundColor(.pink)
            }
            Text(vm.address)
                .foregroundColor(.secondary)
                .font(.custom("Barlow-Regular", size: 16))

            if isEditingAddress {
                VStack(spacing: 8) {
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)

                        TextField("Rechercher une adresse à Saint-Mandé", text: $searchQuery)
                            .focused($isSearchFocused)
                            .onChange(of: searchQuery) { _ in
                                searchForAddress()
                            }

                        if !searchQuery.isEmpty {
                            Button(action: { searchQuery = "" }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 10)
                    .background(Color(.systemGray6))
                    .cornerRadius(12)

                    ForEach(filteredResults, id: \.self) { item in
                        Button {
                            vm.address = item.placemark.title ?? ""
                            withAnimation(.spring()) {
                                isEditingAddress = false
                            }
                        } label: {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.name ?? "Adresse inconnue")
                                    .font(.custom("Barlow-Bold", size: 16))
                                    .foregroundColor(.black)
                                Text(item.placemark.title ?? "")
                                    .font(.custom("Barlow", size: 14))
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 6)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }

    private var finalButton: some View {
        VStack {
            Button(action:{ showSaveAlert = true}) {
                if isSaving {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.pink)
                        .cornerRadius(12)
                } else {
                    Text("Finaliser la commande")
                        .foregroundColor(.white)
                        .font(.custom("Barlow-Bold", size: 18))
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.pink)
                        .cornerRadius(12)
                }
            }
        }
        .padding()
        .background(Color.white)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: -2)
        .alert("Vous confirmer la commande ?", isPresented: $showSaveAlert) {
            Button("Non", role: .cancel) {}
            Button("Oui", role: .destructive) { saveOrder(); menuModel.clearCart()}
        } message: {
            Text("Cette action est irréversible.")
        }
    }

    // MARK: - Filtrage & Recherche
    private var filteredResults: [MKMapItem] {
        searchResults.filter {
            let title = ($0.placemark.title ?? "").lowercased()
            return title.contains("94160") || title.contains("saint-mandé")
        }
    }

    private func searchForAddress() {
        guard !searchQuery.isEmpty else {
            searchResults = []
            return
        }
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchQuery
        request.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 48.8456, longitude: 2.4155),
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
        let search = MKLocalSearch(request: request)
        search.start { response, _ in
            if let items = response?.mapItems {
                searchResults = items
            }
        }
    }

    // MARK: - Sauvegarde
    private func saveOrder() {
        guard let user = Auth.auth().currentUser else { return }
        let uid = user.uid
        isSaving = true

        let db = Firestore.firestore()
        let userRef = db.collection("users").document(uid)

        userRef.getDocument { snapshot, _ in
            let fullName = (snapshot?.data()?["fullName"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            let customerName = (fullName?.isEmpty == false) ? fullName! : (user.email ?? "Client")

            let orderData: [String: Any] = [
                "userId": uid,
                "customerName": customerName, // 👈 ajouté
                "address": vm.address,
                "items": vm.items.map { [
                    "name": $0.id,
                    "price": $0.price,
                    "quantity": $0.quantity
                ]},
                "total": vm.total,
                "itemCount": vm.itemCount,
                "timestamp": Timestamp(date: Date()),
                // Optionnel : statut initial
                "status": "pending"
            ]

            db.collection("orders").addDocument(data: orderData) { error in
                isSaving = false
                if let error = error {
                    print("Erreur lors de l'enregistrement : \(error.localizedDescription)")
                } else {
                    print("Commande enregistrée avec succès")
                    goToTracking = true // ✅ Push vers OrderTrackingView (ou ta vue de suivi)
                }
            }
        }
    }

}
