//
//  CheckoutViewModel.swift
//  Tomo
//
//  Created by Simon Steuer on 08/08/2025.
//

import SwiftUI
import FirebaseAuth
import Combine

class CheckoutViewModel: ObservableObject {
    @Published var address: String
    @Published var items: [MenuItem]
    
    var total: Double {
        items.reduce(0) { $0 + ($1.price * Double($1.quantity)) }
    }
    
    var itemCount: Int {
        items.reduce(0) { $0 + $1.quantity }
    }
    
    init(address: String = "", items: [MenuItem] = []) {
        self.address = address
        self.items = items
    }
    
    convenience init(from menuVM: MenuViewModel, address: String) {
        self.init(address: address, items: menuVM.cart)
    }
}
