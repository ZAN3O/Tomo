//
//  File.swift
//  Tomo
//
//  Created by Simon Steuer on 13/08/2025.
//

import Foundation
import FirebaseFirestore

struct Order: Identifiable, Hashable {
    let id: String
    let userId: String
    let customerName: String
    let address: String
    let total: Double
    let itemsCount: Int
    let createdAt: Date
    let status: String
    let items: [OrderItem]   // ← parsés depuis Firestore
}

struct OrderItem: Identifiable, Hashable {
    let id = UUID()          // pour ForEach
    let name: String
    let price: Double
    let quantity: Int
}
