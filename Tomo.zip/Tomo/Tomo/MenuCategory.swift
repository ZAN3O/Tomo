//
//  MenuCategory.swift
//  Tomo
//
//  Created by Simon Steuer on 05/08/2025.
//

import Foundation


enum MenuCategory: String, CaseIterable {
    case commandeAgain        = "Commandez encore !"

    
    case menuMidiExpress      = "MENU MIDI EXPRESS"
    case menuTomo             = "MENU TOMO"
    case menuDonburi          = "MENU DONBURI"
    case menuNouillesSautees  = "MENU NOUILLES SAUTÉES"
    case menuSushiSashimiMaki = "MENU SUSHI SASHIMI MAKI"
    case menuYakitori         = "MENU YAKITORI"
    case menuTempura          = "MENU TEMPURA"
    case menuMixte            = "MENU MIXTE"

    // Grands plateaux
    case plateauTomo          = "PLATEAU TOMO"
    case bateauRoyal          = "BATEAU ROYAL"

    // Divers
    case specialites          = "SPÉCIALITÉS"
    case horsDoeuvre          = "HORS D'OEUVRE"

    // Listes unitaires
    case makiPar6             = "MAKI (PAR 6)"
    case makiCalifornia       = "MAKI CALIFORNIA"
    case makiDivers           = "MAKI DIVERS"
    case makiPrintemps        = "MAKI PRINTEMPS"
    case sushiParPaire        = "SUSHI (PAR PAIRE)"
    case sashimi              = "SASHIMI"
    case temaki               = "TEMAKI"
    case yakitoriParPaire     = "YAKITORI (PAR PAIRE)"

    var tag: String {
        switch self {
        case .commandeAgain:        return "commandeEncore"
        case .menuMidiExpress:      return "MENU MIDI EXPRESS"
        case .menuTomo:             return "MENU TOMO"
        case .menuDonburi:          return "MENU DONBURI"
        case .menuNouillesSautees:  return "MENU NOUILLES SAUTÉES"
        case .menuSushiSashimiMaki: return "MENU SUSHI SASHIMI MAKI"
        case .menuYakitori:         return "MENU YAKITORI"
        case .menuTempura:          return "MENU TEMPURA"
        case .menuMixte:            return "MENU MIXTE"
        case .plateauTomo:          return "PLATEAU TOMO"
        case .bateauRoyal:          return "BATEAU ROYAL"
        case .specialites:          return "SPÉCIALITÉS"
        case .horsDoeuvre:          return "HORS D'OEUVRE"
        case .makiPar6:             return "MAKI (PAR 6)"
        case .makiCalifornia:       return "MAKI CALIFORNIA"
        case .makiDivers:           return "MAKI DIVERS"
        case .makiPrintemps:        return "MAKI PRINTEMPS"
        case .sushiParPaire:        return "SUSHI (PAR PAIRE)"
        case .sashimi:              return "SASHIMI"
        case .temaki:               return "TEMAKI"
        case .yakitoriParPaire:     return "YAKITORI (PAR PAIRE)"
        }
    }
}

