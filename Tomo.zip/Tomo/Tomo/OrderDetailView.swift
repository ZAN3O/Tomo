//
//  OrderDetailView.swift
//  Tomo
//
//  Created by Simon Steuer on 13/08/2025.
//

//
//  OrderDetailView.swift
//  Tomo
//
//  Created by Simon Steuer on 13/08/2025.
//

import SwiftUI
import FirebaseFirestore

struct OrderDetailView: View {
    let order: Order
    @Environment(\.dismiss) private var dismiss
    @State private var showDeleteAlert = false
    @State private var isDeleting = false
    @State private var currentStatus: String

    init(order: Order) {
        self.order = order
        _currentStatus = State(initialValue: order.status)
    }

    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(spacing: 16) {

                HStack(spacing: 12) {
                    StatusChangeButton(
                        label: "En attente",
                        statusValue: "pending",
                        currentStatus: $currentStatus,
                        color: Color.orange
                    )
                    StatusChangeButton(
                        label: "En livraison",
                        statusValue: "delivering",
                        currentStatus: $currentStatus,
                        color: Color.purple
                    )
                }
                .padding(.vertical, 8)

                // Carte statut + métadonnées
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Commande")
                            .font(.custom("Barlow-Bold", size: 24))
                        Spacer()
                        //StatusPill(status: currentStatus)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("Client :")
                                .font(.custom("Barlow-Bold", size: 16))
                            Text(order.customerName)
                                .font(.custom("barlow", size: 16))
                        }
                        HStack(alignment: .top) {
                            Text("Adresse :")
                                .font(.custom("Barlow-Bold", size: 16))
                            Text(order.address.isEmpty ? "—" : order.address)
                                .font(.custom("barlow", size: 16))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        HStack {
                            Text("Date :")
                                .font(.custom("Barlow-Bold", size: 16))
                            Text(order.createdAt.formatted(date: .abbreviated, time: .shortened))
                                .font(.custom("barlow", size: 16))
                        }
                        HStack {
                            Text("Articles :")
                                .font(.custom("Barlow-Bold", size: 16))
                            Text("\(order.itemsCount)")
                                .font(.custom("barlow", size: 16))
                        }
                    }
                }
                .padding(16)
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                // Carte liste des items
                VStack(alignment: .leading, spacing: 12) {
                    Text("Contenu de la commande")
                        .font(.custom("Barlow-Bold", size: 20))

                    if order.items.isEmpty {
                        Text("Aucun article enregistré.")
                            .font(.custom("barlow", size: 15))
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(order.items) { item in
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.name)
                                        .font(.custom("Barlow-Bold", size: 16))
                                    Text(String(format: "%.2f € • x%d", item.price, item.quantity))
                                        .font(.custom("barlow", size: 14))
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Text(String(format: "%.2f €", item.price * Double(item.quantity)))
                                    .font(.custom("Barlow-Bold", size: 16))
                            }
                            .padding(.vertical, 6)

                            Divider().padding(.leading, 0)
                        }
                        .padding(.top, 4)
                    }
                }
                .padding(16)
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Paiement")
                        .font(.custom("Barlow-Bold", size: 20))

                    HStack {
                        Text("Total")
                            .font(.custom("Barlow-Bold", size: 16))
                        Spacer()
                        Text(String(format: "%.2f €", order.total))
                            .font(.custom("Barlow-Bold", size: 18))
                    }
                }
                .padding(16)
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                Spacer(minLength: 20)

                // Bouton supprimer (livraison terminée)
                Button(action: { showDeleteAlert = true }) {
                    Text(isDeleting ? "Suppression..." : "Livraison faite")
                        .font(.custom("Barlow-Bold", size: 18))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.pink)
                        .cornerRadius(12)
                }
                .disabled(isDeleting)
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
        }
        .background(Color(.systemGray6))
        .navigationTitle("Commande")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Livraison faite ?", isPresented: $showDeleteAlert) {
            Button("Non", role: .cancel) {}
            Button("Oui", role: .destructive) { deleteOrder() }
        } message: {
            Text("Cette action est irréversible.")
        }
    }

    // Mise à jour du statut dans Firestore
    private func updateStatus(to newStatus: String) {
        let db = Firestore.firestore()
        db.collection("orders").document(order.id).updateData([
            "status": newStatus
        ]) { error in
            if let error = error {
                print("Erreur MAJ statut :", error.localizedDescription)
            } else {
                print("Statut MAJ -> \(newStatus)")
                currentStatus = newStatus
            }
        }
    }

    private func deleteOrder() {
        isDeleting = true
        let db = Firestore.firestore()
        db.collection("orders").document(order.id).delete { error in
            isDeleting = false
            if let error = error {
                print("Erreur suppression :", error.localizedDescription)
            } else {
                print("Commande supprimée avec succès")
                dismiss()
            }
        }
    }

    private func StatusChangeButton(label: String, statusValue: String, currentStatus: Binding<String>, color:Color) -> some View {
        Button {
            updateStatus(to: statusValue)
        } label: {
            Text(label)
                .font(.custom("barlow", size: 14))
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(currentStatus.wrappedValue == statusValue ? color : Color(.systemGray5))
                .foregroundColor(currentStatus.wrappedValue == statusValue ? .white : .black)
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}
