//
//  ContentView.swift
//  Tomo
//
//  Created by Simon Steuer on 05/08/2025.
//

import SwiftUI
import FirebaseAuth

struct ContentView: View {
    @State private var isLoggedIn: Bool? = nil
    @State private var isSpecialUser: Bool = false
    
    var body: some View {
        Group {
            if isLoggedIn == nil {
                ProgressView("Chargement...")
                    .progressViewStyle(CircularProgressViewStyle(tint: .pink))
            } else if isLoggedIn == true {
                if isSpecialUser {
                    OrderView()
                } else {
                    MainView()
                }
            } else {
                AuthPage()
            }
        }
        .onAppear {
            Auth.auth().addStateDidChangeListener { _, user in
                withAnimation {
                    if let user = user {
                        isLoggedIn = true
                        isSpecialUser = (user.email?.lowercased() == "tomo94@gmail.com")
                    } else {
                        isLoggedIn = false
                        isSpecialUser = false
                    }
                }
            }
        }
    }
}




#Preview {
    ContentView()
}
