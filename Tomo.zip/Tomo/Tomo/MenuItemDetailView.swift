//
//  MenuItemDetailView.swift
//  Tomo
//
//  Created by Simon Steuer on 10/08/2025.
//


import SwiftUI

struct MenuItemDetailView: View {
    let item: MenuItem
    @ObservedObject var viewModel: MenuViewModel

    @Environment(\.dismiss) private var dismiss
    @State private var quantity: Int = 1

    var body: some View {
        GeometryReader { geo in
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 20) {
                    // Image header
                    Image(item.id)
                        .resizable()
                        .scaledToFill()
                        .frame(width: geo.size.width, height: 300)
                        .clipped()
                        .overlay(
                            LinearGradient(
                                colors: [Color.black.opacity(0.25), .clear],
                                startPoint: .top,
                                endPoint: .center
                            )
                        )

                    // Contenu
                    VStack(alignment: .leading, spacing: 14) {
                        Text("\(item.id) \(item.name)")
                            .font(.custom("Barlow-Bold", size: 28))

                        Text(String(format: "%.2f €", item.price))
                            .font(.custom("Barlow-Bold", size: 14))
                            .foregroundColor(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(Color.black.opacity(0.9))
                            .clipShape(Capsule())
                            .shadow(color: .black.opacity(0.12), radius: 6, x: 0, y: 3)

                        if !item.description.isEmpty {
                            Text(item.description)
                                .font(.custom("Barlow", size: 16))
                                .foregroundColor(.gray)
                        }

                        VStack(spacing: 16) {

                            HStack(spacing: 12) {
                                Button(action: { quantity = max(1, quantity - 1) }) {
                                    Image(systemName: "minus")
                                        .font(.system(size: 18, weight: .bold))
                                        .frame(width: 40, height: 40)
                                        .background(Color(.systemGray5))
                                        .foregroundStyle(.black)
                                        .clipShape(Circle())
                                }

                                Text("\(quantity)")
                                    .font(.system(size: 26, weight: .bold))
                                    .frame(minWidth: 44, alignment: .center)

                                Button(action: { quantity = min(20, quantity + 1) }) {
                                    Image(systemName: "plus")
                                        .font(.system(size: 18, weight: .bold))
                                        .frame(width: 40, height: 40)
                                        .background(Color(.systemGray5))
                                        .foregroundStyle(.black)
                                        .clipShape(Circle())
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.top, 6)

                            Button(action: {
                                for _ in 0..<quantity {
                                    viewModel.addToCart(by: item.id)
                                }
                            }) {
                                Text("Ajouter")
                                    .foregroundColor(.white)
                                    .font(.custom("Barlow-Bold", size: 18))
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.black)
                                    .cornerRadius(12)
                            }
                            .shadow(color: Color.black.opacity(0.08), radius: 5, x: 0, y: 3)
                            .padding(.top,15)
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top, 20)
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 28)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.top, 0)
                .padding(.bottom, 24)
            }
            .ignoresSafeArea(edges: .top)

            // Bouton retour
            .overlay(alignment: .topLeading) {
                BackButtonDefault()
                    .padding(.top, 12)
                    .padding(.leading, 15)
            }
        }
        .background(Color(.systemGray6))
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
    }
}
struct BackButtonDefault: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        HStack {
            Button(action: { dismiss() }) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 48, height: 48)
                    .background(
                        Color.black
                            .shadow(color: .black.opacity(0.15), radius: 4, x: 0, y: 2)
                    )
                    .clipShape(Circle()) // cercle parfait
            }
            Spacer()
        }
        
        .padding(.top, 10)
    }
}



