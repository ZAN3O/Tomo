//  AuthPage.swift
//  Tomo
//
//  Created by Simon Steuer on 09/08/2025.
//

import SwiftUI
import FirebaseAuth
import Combine
import MapKit

struct AuthPage: View {
    @StateObject private var vm = AuthViewModel()
    @FocusState private var focused: Field?
    @State private var searchResults: [MKMapItem] = []

    enum Field { case email, password, confirm, first, last, address, phone }

    // MARK: - Password policy helpers
    private var hasLowercase: Bool { vm.password.rangeOfCharacter(from: .lowercaseLetters) != nil }
    private var hasUppercase: Bool { vm.password.rangeOfCharacter(from: .uppercaseLetters) != nil }
    private var hasDigit: Bool     { vm.password.rangeOfCharacter(from: .decimalDigits) != nil }
    private var hasSpecial: Bool   { vm.password.rangeOfCharacter(from: CharacterSet.punctuationCharacters.union(.symbols)) != nil }
    private var hasLength: Bool    { vm.password.count >= 10 }

    private var isPasswordCompliant: Bool {
        hasLowercase && hasUppercase && hasDigit && hasSpecial && hasLength
    }
    private var passwordsMatch: Bool {
        !vm.password.isEmpty && vm.password == vm.confirmPassword
    }

    // Force meter (red → yellow → green)
    private var passwordScore: Int {
        var s = 0
        if hasLength { s += 2 } else if vm.password.count >= 8 { s += 1 }
        if hasLowercase { s += 1 }
        if hasUppercase { s += 1 }
        if hasDigit     { s += 1 }
        if hasSpecial   { s += 1 }
        return min(s, 6)
    }
    private var strengthProgress: Double { Double(passwordScore) / 6.0 }
    private var strengthColor: Color {
        switch strengthProgress {
        case 0..<0.34: return .red
        case 0..<0.67: return .yellow
        default:       return .green
        }
    }
    private var strengthLabel: String {
        switch strengthProgress {
        case 0..<0.34: return "Faible"
        case 0..<0.67: return "Moyen"
        default:       return "Fort"
        }
    }

    private var canSubmitSignup: Bool {
        vm.isFormValid && isPasswordCompliant && passwordsMatch
    }

    var body: some View {
        NavigationStack {
            Group {
                if vm.mode == .login {
                    // ===== Connexion =====
                    VStack(spacing: 24) {
                        logo
                        title
                        loginFields
                        errorView
                        primaryButton
                        switchModeButton
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 40)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                } else {
                    // ===== Inscription =====
                    ScrollView {
                        VStack(spacing: 24) {
                            logo
                            title
                            signupFields 
                            errorView
                            primaryButton
                            switchModeButton
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 40)
                        .padding(.bottom, 24)
                    }
                    .scrollDismissesKeyboard(.interactively)
                }
            }
            .background(Brand.bg)
            .navigationBarBackButtonHidden(true)
            .toolbar { keyboardToolbar }
        }
    }

    // MARK: - Subviews

    private var logo: some View {
        Group {
            if let uiImg = UIImage(named: "tomo_logo") {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 88, height: 88)
            } else {
                Image(systemName: "takeoutbag.and.cup.and.straw")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                    .foregroundColor(Brand.pink)
            }
        }
    }

    private var title: some View {
        Text(vm.mode == .login ? "Connexion" : "Créer un compte")
            .font(.custom("Barlow-Bold", size: 28))
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var loginFields: some View {
        VStack(spacing: 14) {
            LabeledField(title: "Email", text: $vm.email)
                .textInputAutocapitalization(.never)
                .keyboardType(.emailAddress)
                .focused($focused, equals: .email)

            SecureLabeledField(title: "Mot de passe", text: $vm.password)
                .focused($focused, equals: .password)
        }
    }

    // MARK: - Signup fields (password & confirm stacked)
    @State private var searchQuery = ""

    private var signupFields: some View {
        VStack(spacing: 14) {
            LabeledField(title: "Email", text: $vm.email)

            VStack(alignment: .leading, spacing: 8) {
                SecureLabeledField(title: "Mot de passe", text: $vm.password)
                    .focused($focused, equals: .password)

                // Barre de force (inchangée)
                if !vm.password.isEmpty {
                    ProgressView(value: strengthProgress) {
                        Text("Force : \(strengthLabel)")
                            .font(.custom("Barlow", size: 12))
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 6) // ✅ espace pour la rendre lisible
                    .progressViewStyle(.linear)
                    .tint(strengthColor)
                    .frame(height: 45)
                    .clipShape(Capsule())
                }

                VStack(alignment: .leading, spacing: 6) {
                    RequirementRow(ok: hasLength,    text: "Au moins 10 caractères")
                    RequirementRow(ok: hasUppercase, text: "Au moins une majuscule (A–Z)")
                    RequirementRow(ok: hasLowercase, text: "Au moins une minuscule (a–z)")
                    RequirementRow(ok: hasDigit,     text: "Au moins un chiffre (0–9)")
                    RequirementRow(ok: hasSpecial,   text: "Au moins un caractère spécial (!@#&…)")
                }
                .padding(.top, 2)
            }

            VStack(alignment: .leading, spacing: 6) {
                SecureLabeledField(title: "Confirmer", text: $vm.confirmPassword)
                    .focused($focused, equals: .confirm)

                if !vm.confirmPassword.isEmpty {
                    HStack(spacing: 6) {
                        Image(systemName: passwordsMatch ? "checkmark.circle.fill" : "xmark.octagon.fill")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(passwordsMatch ? .green : .red)
                        Text(passwordsMatch ? "Les mots de passe correspondent." : "Les mots de passe ne correspondent pas.")
                            .font(.custom("Barlow", size: 12))
                            .foregroundColor(.secondary)
                    }
                    .transition(.opacity)
                }
            }

            // Infos perso
            LabeledField(title: "Prénom", text: $vm.firstName)
            LabeledField(title: "Nom", text: $vm.lastName)

            // Adresse avec recherche
            VStack(alignment: .leading, spacing: 6) {
                Text("Adresse")
                    .font(.custom("Barlow-Bold", size: 14))
                    .foregroundColor(.gray)

                TextField("Rechercher une adresse", text: $searchQuery)
                    .padding(12)
                    .background(Brand.field)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Brand.border))
                    .onChange(of: searchQuery) { newValue in
                        searchAddresses(query: newValue)
                    }

                if !searchResults.isEmpty {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(searchResults, id: \.self) { item in
                            Button {
                                vm.address = item.placemark.title ?? ""
                                searchQuery = vm.address
                                searchResults = []
                            } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(item.name ?? "Adresse inconnue")
                                        .font(.custom("Barlow-Bold", size: 16))
                                        .foregroundColor(.black)
                                    Text(item.placemark.title ?? "")
                                        .font(.custom("Barlow", size: 14))
                                        .foregroundColor(.gray)
                                }
                                .padding(.vertical, 8)
                                .padding(.horizontal, 8)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color.white)
                            }
                            .buttonStyle(.plain)

                            if item != searchResults.last { Divider() }
                        }
                    }
                    .background(Color.white)
                    .cornerRadius(8)
                    .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                    .padding(.top, 4)
                }
            }

            LabeledField(title: "Téléphone", text: $vm.phone, keyboard: .phonePad)
        }
    }

    // MARK: - Search
    private func searchAddresses(query: String) {
        guard !query.isEmpty else { searchResults = []; return }
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        request.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 48.8456, longitude: 2.4155),
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
        MKLocalSearch(request: request).start { response, _ in
            if let items = response?.mapItems {
                searchResults = items.filter {
                    let title = ($0.placemark.title ?? "").lowercased()
                    return title.contains("94160") || title.contains("saint-mandé")
                }
            }
        }
    }

    // MARK: - Error + actions
    private var errorView: some View {
        Group {
            if let error = vm.errorMessage, !error.isEmpty {
                Text(error)
                    .font(.callout)
                    .foregroundColor(.orange)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else if vm.mode == .signup && !vm.password.isEmpty && !isPasswordCompliant {
                Text("Mot de passe trop faible (≥10 car., maj/min, chiffre, caractère spécial).")
                    .font(.callout)
                    .foregroundColor(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else if vm.mode == .signup && !vm.confirmPassword.isEmpty && !passwordsMatch {
                Text("Les mots de passe ne correspondent pas.")
                    .font(.callout)
                    .foregroundColor(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var primaryButton: some View {
        let canSubmit = vm.mode == .login ? vm.isFormValid : canSubmitSignup
        return Button(action: vm.submit) {
            Text(vm.mode == .login ? "Se connecter" : "Créer mon compte")
                .foregroundColor(.white)
                .font(.custom("Barlow-Bold", size: 18))
                .frame(maxWidth: .infinity)
                .padding()
                .background(canSubmit ? Brand.pink : Brand.pink.opacity(0.4))
                .cornerRadius(12)
        }
        .disabled(!canSubmit || vm.isLoading)
    }

    private var switchModeButton: some View {
        Button {
            withAnimation { vm.mode = vm.mode == .login ? .signup : .login }
        } label: {
            Text(vm.mode == .login
                 ? "Vous n'avez pas de compte ? Inscrivez-vous"
                 : "Déjà inscrit ? Connectez-vous")
            .font(.custom("barlow", size: 12))
            .foregroundColor(Brand.pink)
        }
    }

    // MARK: - Keyboard toolbar
    private var keyboardToolbar: some ToolbarContent {
        ToolbarItemGroup(placement: .keyboard) {
            Spacer()
            Button("Terminé") { focused = nil }
        }
    }
}

private struct RequirementRow: View {
    let ok: Bool
    let text: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: ok ? "checkmark.circle.fill" : "circle")
                .foregroundColor(ok ? .green : .secondary)
            Text(text)
                .font(.custom("barlow", size: 13))
                .foregroundColor(.secondary)
        }
    }
}
