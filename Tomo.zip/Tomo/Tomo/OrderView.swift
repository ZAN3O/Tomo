//
//  OrderView.swift
//  Tomo
//
//  Created by Simon Steuer on 13/08/2025.
//

import SwiftUI
import FirebaseAuth

import SwiftUI
import FirebaseAuth

struct OrderView: View {
    @StateObject private var viewModel = MenuViewModel()
    @State private var showAccountSheet = false
    @State private var signOutError: String?
    @State private var searchText: String = ""
    @State private var filterMode: FilterMode = .all

    // Filtre sur texte + statut
    private var searchResults: [Order] {
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        var filtered = viewModel.orders

        // Appliquer le filtre en fonction du mode
        switch filterMode {
        case .commandes:
            filtered = filtered.filter { $0.status.lowercased() == "pending" || $0.status.lowercased() == "preparing" }
        case .livraison:
            filtered = filtered.filter { $0.status.lowercased() == "ready" || $0.status.lowercased() == "delivering" }
        case .all:
            break
        }

        guard !q.isEmpty else { return filtered }
        return filtered.filter { order in
            order.customerName.lowercased().contains(q)
        }
    }

    private var userInitials: String {
        if let user = Auth.auth().currentUser {
            if let name = user.displayName, !name.trimmingCharacters(in: .whitespaces).isEmpty {
                return Self.initials(from: name)
            }
            if let email = user.email, !email.isEmpty {
                let base = email.split(separator: "@").first.map(String.init) ?? ""
                return Self.initials(from: base)
            }
        }
        return "TU"
    }

    var body: some View {
        NavigationStack {
            ZStack {
                VStack(spacing: 16) {
                    // Header
                    HStack {
                        Text("Commandes")
                            .font(.custom("Barlow-Bold", size: 45))
                            .bold()
                        Spacer()
                        Button { showAccountSheet = true } label: {
                            AvatarInitials(initials: userInitials, size: 46, corner: 12)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)

                    // Barre de recherche
                    OrderSearchBar(text: $searchText)
                        .padding(.horizontal, 16)

                    HStack(spacing: 12) {
                        FilterPill(title: "Toutes", isSelected: filterMode == .all, color: .gray) {
                            filterMode = .all
                        }
                        FilterPill(title: "Commandes", isSelected: filterMode == .commandes, color: .orange) {
                            filterMode = .commandes
                        }
                        FilterPill(title: "Livraison", isSelected: filterMode == .livraison, color: .purple) {
                            filterMode = .livraison
                        }
                    }
                    .padding(.horizontal, 16)

                    // Liste
                    if searchResults.isEmpty {
                        VStack(spacing: 10) {
                            Text("Aucune commande")
                                .font(.custom("barlow", size: 16))
                                .foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        ScrollView(.vertical, showsIndicators: false) {
                            LazyVStack(spacing: 12) {
                                ForEach(searchResults) { order in
                                    NavigationLink(value: order) {
                                        OrderRow(order: order)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.bottom, 8)
                        }
                    }
                }
                .background(Color(.systemGray6))
                .ignoresSafeArea(edges: .bottom)
            }
            .navigationDestination(for: Order.self) { order in
                OrderDetailView(order: order)
            }
        }
        .sheet(isPresented: $showAccountSheet) {
            AccountSheetLarge(signOutError: $signOutError)
                .presentationDetents([.fraction(0.92)])
                .presentationCornerRadius(28)
        }
        .onAppear {
            let isAdmin = Auth.auth().currentUser?.email?.lowercased() == "tomo94@gmail.com"
            viewModel.fetchOrders(forAdmin: isAdmin)
        }
    }

    private static func initials(from name: String) -> String {
        let parts = name.trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: .whitespaces)
            .filter { !$0.isEmpty }
        if parts.count >= 2 {
            return (String(parts[0].first!) + String(parts[1].first!)).uppercased()
        } else if let first = parts.first?.first {
            return String(first).uppercased()
        } else {
            return "TU"
        }
    }
}

// MARK: - Filtre
enum FilterMode {
    case all, commandes, livraison
}

struct FilterPill: View {
    let title: String
    let isSelected: Bool
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.custom("barlow", size: 14))
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(isSelected ? color : Color(.systemGray5))
                .foregroundColor(isSelected ? .white : .black)
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}



private struct OrderRow: View {
    let order: Order

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // Badge date
            VStack(alignment: .leading, spacing: 4) {
                Text(order.createdAt.formatted(date: .abbreviated, time: .shortened))
                    .font(.custom("barlow", size: 13))
                    .foregroundColor(.secondary)

                Text(order.customerName)
                    .font(.custom("Barlow-Bold", size: 18))
                    .foregroundColor(.black)

                if !order.address.isEmpty && order.address != "—" {
                    Text(order.address)
                        .font(.custom("barlow", size: 14))
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                        .truncationMode(.tail)
                }

                HStack(spacing: 8) {
                    StatusPill(status: order.status)
                    Text("\(order.itemsCount) article\(order.itemsCount > 1 ? "s" : "")")
                        .font(.custom("barlow", size: 13))
                        .foregroundColor(.secondary)
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 6) {
                Text(String(format: "%.2f €", order.total))
                    .font(.custom("Barlow-Bold", size: 18))
                    .foregroundColor(.black)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.secondary)
            }
        }
        .padding(14)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

struct StatusPill: View {
    let status: String

    var body: some View {
        Text(label(for: status))
            .font(.custom("barlow", size: 12))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(backgroundColor(for: status))
            .foregroundColor(.white)
            .clipShape(Capsule())
    }

    private func label(for status: String) -> String {
        switch status.lowercased() {
        case "pending": return "En attente"
        case "preparing": return "En préparation"
        case "ready": return "Prête"
        case "delivering": return "En livraison"
        case "delivered": return "Livrée"
        case "canceled", "cancelled": return "Annulée"
        default: return status.capitalized
        }
    }

    private func backgroundColor(for status: String) -> Color {
        switch status.lowercased() {
        case "pending": return .orange
        case "preparing": return .blue
        case "ready": return .green
        case "delivering": return .purple
        case "delivered": return .gray
        case "canceled", "cancelled": return .red
        default: return .black
        }
    }
}

struct OrderDetailPlaceholder: View {
    let order: Order
    var body: some View {
        VStack(spacing: 12) {
            Text("Détails de la commande")
                .font(.custom("Barlow-Bold", size: 28))
            Text("ID: \(order.id)")
                .font(.custom("barlow", size: 16))
            Text("Client: \(order.customerName)")
                .font(.custom("barlow", size: 16))
            Text("Total: \(String(format: "%.2f €", order.total))")
                .font(.custom("barlow", size: 16))
            Spacer()
        }
        .padding()
        .navigationTitle("Commande")
    }
}

struct OrderSearchBar: View {
    @Binding var text: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.gray)

            TextField("", text: $text)
                .font(.custom("barlow", size: 16))
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
                .placeholder(when: text.isEmpty, alignment: .leading) {
                    Text("Rechercher une commande…")
                        .font(.custom("barlow", size: 16))
                        .foregroundColor(.secondary)
                }
        }
        .padding(.horizontal, 12)
        .frame(height: 44)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}
#Preview {
    OrderView()
}
