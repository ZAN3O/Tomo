import SwiftUI

struct BottomNavBar: View {
    @Binding var selectedIndex: Int

    let icons = ["house.fill", "person.crop.circle"]

    var body: some View {
        HStack {
            ForEach(0..<icons.count, id: \.self) { i in
                Spacer()
                Button(action: {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                        selectedIndex = i
                    }
                }) {
                    Image(systemName: icons[i])
                        .font(.system(size: selectedIndex == i ? 26 : 22, weight: .semibold))
                        .foregroundColor(selectedIndex == i ? .black : .gray)
                        .scaleEffect(selectedIndex == i ? 1.2 : 1.0)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 16)
                        .background(
                            Circle()
                                .fill(selectedIndex == i ? Color.gray.opacity(0.1) : Color.clear)
                        )
                }
                Spacer()
            }
        }
        .background(Color.white)
        .padding(.horizontal, 32)
        
        .padding(.top,8)
    }
}
