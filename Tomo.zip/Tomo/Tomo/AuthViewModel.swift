//
//  AuthViewModel.swift
//  Tomo
//
//  Created by Simon Steuer on 09/08/2025.
//
import SwiftUI
import Combine
import FirebaseAuth
import FirebaseFirestore

@MainActor
final class AuthViewModel: ObservableObject {
    enum Mode { case login, signup }
    @Published var mode: Mode = .login
    @Published var isLoading = false
    @Published var errorMessage: String?

    // Champs communs
    @Published var email = ""
    @Published var password = ""

    // Champs inscription
    @Published var firstName = ""
    @Published var lastName = ""
    @Published var address = ""
    @Published var phone = ""
    @Published var confirmPassword = ""

    // Validation
    var isEmailValid: Bool {
        let pattern = #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#
        return email.range(of: pattern, options: [.regularExpression, .caseInsensitive]) != nil
    }
    var isPasswordValid: Bool { password.count >= 6 }
    var passwordsMatch: Bool { password == confirmPassword }

    var isFormValid: Bool {
        switch mode {
        case .login: return isEmailValid && isPasswordValid
        case .signup:
            return isEmailValid && isPasswordValid && passwordsMatch && !firstName.isEmpty && !lastName.isEmpty
        }
    }

    private let db = Firestore.firestore()

    func submit() {
        errorMessage = nil
        switch mode {
        case .login: signIn()
        case .signup: signUp()
        }
    }

    private func signIn() {
        guard isFormValid else { return }
        isLoading = true
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] _, error in
            guard let self else { return }
            self.isLoading = false
            if let e = error as NSError? { self.errorMessage = Self.mapAuthError(e); return }
            self.loadProfileToLocal()
        }
    }


    private func signUp() {
        guard isFormValid else { return }
        isLoading = true

        Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
            guard let self else { return }
            if let e = error as NSError? {
                self.isLoading = false
                self.errorMessage = Self.mapAuthError(e)
                return
            }
            guard let user = result?.user else { self.isLoading = false; return }
            let uid = user.uid

            // 1) displayName Firebase (pour tes initiales)
            let change = user.createProfileChangeRequest()
            change.displayName = "\(self.firstName) \(self.lastName)".trimmingCharacters(in: .whitespaces)
            change.commitChanges { _ in }

            // 2) Profil Firestore
            let userData: [String: Any] = [
                "uid": uid,
                "email": self.email,
                "firstName": self.firstName,
                "lastName": self.lastName,
                "fullName": "\(self.firstName) \(self.lastName)",
                "address": self.address,
                "phone": self.phone,
                "createdAt": FieldValue.serverTimestamp()
            ]
            self.db.collection("users").document(uid).setData(userData) { err in
                // 3) Cache local (pour tes vues)
                UserDefaults.standard.set("\(self.firstName) \(self.lastName)", forKey: "userFullName")
                UserDefaults.standard.set(self.address, forKey: "userAddress")
                self.isLoading = false
                if let err { self.errorMessage = "Compte créé, profil non sauvegardé: \(err.localizedDescription)" }
            }
        }
    }


    static func mapAuthError(_ error: NSError) -> String {
        guard let code = AuthErrorCode(rawValue: error.code) else { return error.localizedDescription }
        switch code {
        case .invalidEmail: return "Adresse email invalide."
        case .emailAlreadyInUse: return "Email déjà utilisé."
        case .weakPassword: return "Mot de passe trop faible (≥ 6 caractères)."
        case .userNotFound, .wrongPassword: return "Identifiants incorrects."
        case .networkError: return "Problème réseau, réessaie."
        case .tooManyRequests: return "Trop de tentatives, attends un peu."
        default: return error.localizedDescription
        }
    }
    func loadProfileToLocal() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        db.collection("users").document(uid).getDocument { snap, _ in
            guard let data = snap?.data() else { return }
            let fullName = (data["fullName"] as? String)
                ?? [data["firstName"] as? String, data["lastName"] as? String].compactMap{$0}.joined(separator: " ")
            let address  = data["address"] as? String ?? ""
            UserDefaults.standard.set(fullName, forKey: "userFullName")
            UserDefaults.standard.set(address,  forKey: "userAddress")
        }
    }

}

