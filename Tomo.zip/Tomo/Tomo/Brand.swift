//
//  Brand.swift
//  Tomo
//
//  Created by Simon Steuer on 09/08/2025.
//
import Foundation
import SwiftUI

struct Brand {
    static let bg = Color(uiColor: .systemGroupedBackground)
    static let card = Color.white
    static let field = Color.white
    static let border = Color.black.opacity(0.06)
    static let pink = Color.pink
}
