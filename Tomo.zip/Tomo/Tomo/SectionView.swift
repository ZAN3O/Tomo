import SwiftUI

struct SectionView: View {
    let title: String
    let items: [MenuItem]
    let onDropInBasket: (String) -> Void
    let viewModel: MenuViewModel

    @State private var selectedItem: MenuItem?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            // Titre avec un léger padding gauche
            Text(title)
                .font(.custom("Barlow-Regular", size: 20))
                .padding(.leading, 16)

            // Carrousel horizontal
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 14) {
                    ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                        CardView(item: item, viewModel: viewModel)
                            .contentShape(Rectangle())
                            .onTapGesture { selectedItem = item }
                            .padding(.leading, index == 0 ? 16 : 0)
                            .padding(.trailing, index == items.count - 1 ? 16 : 0)
                    }
                }
                .padding(.vertical, 6)
                .scrollClipDisabled() // laisse les ombres dépasser
            }
        }
        .padding(.vertical, 4)
        .navigationDestination(item: $selectedItem) { item in
            MenuItemDetailView(item: item, viewModel: viewModel)
        }
    }
}

