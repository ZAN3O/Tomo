//
//  TomoTests.swift
//  TomoTests
//
//  Created by Simon Steuer on 05/08/2025.
//

import Testing

struct TomoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
